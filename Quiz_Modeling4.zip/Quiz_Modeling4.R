# <Modeling 4> Tuning -------------------------------------------

# 포르투갈 은행 마케팅 데이터("bank_marketing.csv")를 이용해 예금 상품 가입 촉진 텔레마케팅에 반응해 상품에 가입할 고객을 예측하는 모델을 만들어보세요.

# - 5 fold Cross validation을 활용해 precision 기준으로 모델의 성능을 평가하세요.
# - 하이퍼파라미터(cost_complexity, tree_depth)를 3 level로 만들어 튜닝하세요.
# - 튜닝하지 않은 기본 모형을 만들어 성능을 비교하세요.

# 데이터 설명: https://archive.ics.uci.edu/ml/datasets/Bank+Marketing
# 원본: https://archive.ics.uci.edu/ml/machine-learning-databases/00222/
